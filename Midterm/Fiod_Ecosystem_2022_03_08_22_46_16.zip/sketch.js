//Name : Hassan Hamdani
//Date : 09/05/2022
// Fiod Ecosystem Project

//*******   CUSTOMIZE    *******

//Customizing Parameters in the Simulation
let population = 10;
let foodAmount = 20;
let poisonAmount = 20;
let evolveRate = 0.1;
let survivalPop = 20;

// *****************************

//lists for vehicles, food and poison
let v = [];      
let food = [];
let poison = [];

//food and poison will spawn every few seconds
let timer1=0;
let timer2=0;
let timer3=0;

//Switch between start screen and simulation screen, mousePressed() will be used
let mode=0;

function setup() {
  createCanvas(750,500);
  
  //creating vehicles
  for(var i=0; i<population; i++){
    var x = random(width);
    var y = random(height);
    v[i] = new Vehicle(x,y);
  }
  
  //creating food spots randomly
  for(var i=0; i<foodAmount; i++){
    var x = random(width-20);
    var y = random(height-20);
    food.push(createVector(x,y));
  }

  //creating poison spots randomly
  for(var i=0; i<poisonAmount; i++){
    var x = random(width-20);
    var y = random(height-20);
    poison.push(createVector(x,y));
  }
    
}

//////////////////////////////////////////////////

function draw() {

//Displaying a start screen with a legend and custom controls
  if(mode==0){
    background(143, 85, 56);
    
    //Title
    textFont("Arial");
    textSize(80);
    fill(200);
    text("Fiod Ecosystem", 100,80)
    
    //Seperator
    stroke(200);
    strokeWeight(4);
    line(500,120,500,480);
    
    //legend
    strokeWeight(1);
    textSize(30);
    fill(200);
    text("Legend", 520,140);
    
    //Continue
    textSize(20);
    fill(200);
    text("Click to continue...", 580,480);
    
    //Food
    fill(0,255,0)
    ellipse(520,180,10,10);
    textSize(16);
    fill(200)
    text("Food", 535,185);
    
    //Poison
    fill(255,0,255)
    ellipse(620,180,10,10);
    textSize(16);
    fill(200)
    text("Poison", 635,185);
    
    //Health Bar 
    fill(200);
    text("Health Bar", 565,220);
    fill(255,0,0)
    rect(535, 230, 20, 30);
    fill(127)
    rect(535, 260, 20, 30);
    fill(245, 147, 66);
    rect(535, 290, 20, 30);
    fill(239, 245, 66);
    rect(535, 320, 20, 30);
    fill(141, 245, 66);
    rect(535, 350, 20, 30);
    
    noStroke();
    textSize(14);
    fill(255,0,0);
    text("Dead",580,245);
    
    fill(127);
    text("Born", 582, 280);
    
    fill(141, 245, 66);
    text("Reproduce", 582, 370);
    
    //Evolve
    fill(127);
    triangle(535, 420, 535, 440, 560, 430);
    fill(184, 153, 17);
    textSize(30)
    text("➞", 605,440);
    textSize(14);
    text("Evolved", 595,420);
    fill(255);
    triangle(680, 415, 680, 445, 710, 430);
    
    //Description
    
    fill(200);
    strokeWeight(1);
    textFont("Arial");
    textSize(40);
    text("Description", 40, 170);
    
    textSize(15);
    text("Welcome To The Fiod Ecosystem. This simulational program \nwhere bots can be placed in environments you wish to create.\nThere are two main objects in the simulation, food and poison,\n where food represents everything that helps a species survive,\nand poison is everything that leads to extinction. Whether a bot \ngoes towards food or poison is based on a random function. \nThis function starts with giving every bot a 50-50 chance to choose\n between food and poison. The bots also have the capability to \nevolve, where their intelligence increases. This means, their ability \nto choose food over poison increases, and the amount of food \nthey need to consume to reproduce decreases. The program has \ntwo endings: When all the bots are dead, or the population has \nincreased to a certain threshold. To model specific ecosystems, \nparameters that can be controlled by a user through accessing \nthe code and checking under the Customization tab." , 40,210);
    
  }
  
  else{
    
    background(212,240,249);

    //drawing food from the list
    for(var i = 0; i<food.length ; i++){
      fill(0,255,0);
      noStroke();
      //add some jiggle for realism
      var move = random(5,10); 
      ellipse(food[i].x + move,food[i].y+move, 10, 10)
    }

    //drawing poison from the list
    for(var i = 0; i<poison.length ; i++){
      fill(255,0,255);
      noStroke(); 
      //add some jiggle for realism
      var move = random(5,10);
      ellipse(poison[i].x+ move,poison[i].y+ move, 10, 10)
    }

    //each vehicle has a weighted chance of choosing food or poison    
    for(var i =0; i<v.length; i++){
      var choice = random(0,2);

      //probability of taking food over poison increases as intelligence of the vehicle increases
      if(choice<v[i].intel){v[i].eat(food);}
      if(choice>v[i].intel){v[i].eat(poison);}


    v[i].update();
    v[i].display();
    }


  //////////////////   TIME    ////////////////////////////////

//These events take place at set time increments, using millis() that evolve the ecosystem as it grows
    
  //Food spawning
    if(millis() >= 500+timer1){

      var x = random(width-20);
      var y = random(height-20);
      food.push(createVector(x,y));

      fill(0,255,0);
      noStroke(); 
      //add some jiggle for realism
      var move1 = random(5,10);
      ellipse(x + move1,y+move1, 10, 10);

      timer1 = millis(); //move time forward
    }

  //Poison spawning
    if(millis() >= 500+timer2){

      var a = random(width-20);
      var b = random(height-20);
      poison.push(createVector(a,b));

      fill(255,0 ,255);
      noStroke(); 
      //add some jiggle for realism
      var move2 = random(5,10);
      ellipse(a + move2,b+move2, 10, 10);

      timer2 = millis(); //move time forward
    }

    //Random Mutations!!

    //random mutation occurs randomly with time
    if(millis() >= 5000+timer3){  

      //there is a 10% chance that the vehicle will learn, this percentage can be changed in the customize tab
      
      if(random(1)>1-(evolveRate)){
        let mutate = random(v);

        //The probability of choosing food increases by increasing v.intel, and there is a limit so the vehicle can still consume poison
        if(mutate.intel<1.7){
          mutate.intel = mutate.intel +0.2;
        }
      }
      timer3 = millis() 
    }
  //////////////////////////////////////////////////

// This part produces different screens, for two endings: failure and success
    
    
    //EcoSystem Failure 
      var checker = v.length;

      //checking if all vehicles are dead
      for(var i=0; i<v.length; i++)
        {
          if(v[i].maxspeed==0){checker--; }
        }
      //if dead, then end ecosystem
      if(checker==0){
        fill(255,0,0);
        rect(0,0,width,height);
        fill(0);
        textSize(60);
        text("Ecosystem has Failed!",80,height/2);
      }

    //EcoSystem Successful
    
    //Once enough reproduction has happened, this variable survivalPop can be changed from the customize tab
    
    if(v.length>survivalPop)
      {
        fill(0,255,0);
        rect(0,0,width,height);
        fill(0);
        textSize(60);
        text("Ecosystem has Survived!", 50, height/2);
      }
  }
}

//Screen Switching when mouse pressed, One screen for the legend and description, and the other for the actual ecosystem.

function mousePressed() {
  if (mode == 0) {
    mode = 1;
  }
}
