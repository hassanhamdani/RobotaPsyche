//Describing the different attributes controlling the motion of the vehicles, energy is for reproduction or death, and intel is for controlling the probability of choosing food over poison. The rest are for the motion and visuals.

class Vehicle {
  constructor(x, y) {
    this.acceleration = createVector(0, 0);
    this.velocity = createVector(0, -2);
    this.position = createVector(x, y);
    this.r = 6;
    this.maxspeed = 4;
    this.maxforce = 0.4;
    this.energy = 2;
    this.intel = 1;
  }

  // Method to update location
  update() {
    // Update velocity
    this.velocity.add(this.acceleration);
    // Limit speed
    this.velocity.limit(this.maxspeed);
    this.position.add(this.velocity);
    // Reset accelerationelertion to 0 each cycle
    this.acceleration.mult(0);
  }

  applyForce(force) {
    // We could add mass here if we want A = F / M
    this.acceleration.add(force);
  }
  
  eat(list){
    var record = Infinity;
    var closestIndex = -1;
    
    //get the closest item in given list, food or poison
    for(var i = 0; i<list.length ;  i++)
      {
        var d = this.position.dist(list[i]);
        if(d<record){
          record = d;
          closestIndex = i;
        }
      }
    
    //seek it using steer
    this.seek(list[closestIndex]);
    
    //if food is eaten, then it is removed from list and energy is gained
    if(record < 5){
      if(list[closestIndex]==food[closestIndex]){
        this.energy ++;
          if(food.length>1){ //One food spot always remains
          food.splice(closestIndex,1);
        }
        if(this.energy>10) //Reproduction if enough food is eaten
          {
            //A new vehicle is spawned in the middle of the screen, with the same intel as its parent
            var offspring = new Vehicle(width/2,height/2);
            v.push(offspring);
            this.energy=1;
            offspring.intel = this.intel;
          }
        
        //For specifically evolved vehicles, energy threshold for reproduction is dropped to 7 from 10, and the evolved offspring also starts with greater energy
        
        if(this.intel>1 && this.energy > 7)
          {
            var offspring = new Vehicle(width/2,height/2);
            v.push(offspring);
            this.energy=1;
            offspring.intel = this.intel;
            offspring.energy = 4;
          }
      }
      
      //If poison is consumed energy is decreased and the poison spot is erased
      else{
        if(this.energy>-2){
          this.energy --;
        }
        
        if(poison.length>1){
          poison.splice(closestIndex,1);
        }
        if(this.energy<-1){ //Death if too much poison is eaten
          this.maxspeed = 0;
        }
      }
      }
  }

  // A method that calculates a steering force towards a target
  // STEER = DESIRED MINUS VELOCITY
  seek(target) {

    var desired = p5.Vector.sub(target, this.position); // A vector pointing from the location to the target

    // Scale to maximum speed
    desired.setMag(this.maxspeed);

    // Steering = Desired minus velocity
    var steer = p5.Vector.sub(desired, this.velocity);
    steer.limit(this.maxforce); // Limit to maximum steering force

    this.applyForce(steer);
  }

  display() {
    // Draw a triangle rotated in the direction of velocity
    let theta = this.velocity.heading() + PI / 2;
    fill(127);
    if(this.maxspeed == 0){fill(255,0,0);} //Turn red if dead
    
    //Color changes as energy grows
    if(this.energy>3){
      fill(245, 147, 66)
    }
    if(this.energy>7)
      {
        fill(239, 245, 66);
      }
    if(this.energy>9){
      fill(141, 245, 66);
    }
    
    stroke(200);
    strokeWeight(1);
    push();
    translate(this.position.x, this.position.y);
    rotate(theta);
    beginShape();
    
    //For Evolved Vehicles
    if(this.intel>1){
      stroke(255);
      strokeWeight(6);
    }
    
    //Triangles grow with more energy, bigger vehicles are closer to reproduction
    
    vertex(0, -this.r * 2 *this.energy *0.1);
    vertex(-this.r, this.r * 2);
    vertex(this.r, this.r * 2 );
    
    endShape(CLOSE);
    pop();
    
  }
}